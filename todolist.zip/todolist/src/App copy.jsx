import './App.css'
import Header from './components/Header';
import Editor from './components/Editor';
import List from './components/List';
import { useState, useRef } from 'react';
import ImgExam from './components/ImgExam';

const mockTodo =[
{ id:0,
  isDone:false,   //체크박스 true-체크, false-해제
  content:"React 공부하기",
  createDate : new Date().getTime(),
},
{ id:1,
  isDone:false,   //체크박스 true-체크, false-해제
  content:"빨래하기",
  createDate : new Date().getTime(),
},
{ id:2,
  isDone:false,   //체크박스 true-체크, false-해제
  content:"노래 연습하기",
  createDate : new Date().getTime(),
},
];

function App() {
  const [todo, setTodo] = useState(mockTodo);
  const idRef = useRef(3);
  const onCreate = (content) =>{
    const newItem={
      id:idRef.current++,
      content:content,
      isDone:false,
      createDate:new Date().getTime()
    };

   setTodo([newItem,...todo]);
  }
  const onUpdate = (targetId) => {
    setTodo(
      todo.map((it) =>{
      if(it.id === targetId){
        return {...it,
               isDone: !it.isDone};
      }else{
        return it;
      }}) );
  };

  return (
    <div className='App'>
      <ImgExam />
     <Header />
     <Editor onCreate={onCreate}/>
     <List todo={todo} onUpdate={onUpdate} />
    </div>
  );
}

export default App

