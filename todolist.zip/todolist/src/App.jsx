import './App.css'
import { Routes, Route, Link} from 'react-router-dom';
import Home from "./components/Home";
import Content from './components/Content';
import About from './components/About';

function App() {
    return (
    <div className='App'>
         <div className='App'>
         <div className='link'>
        <a href="/home">Home</a>  
        <a href="/content">Content</a>  
        <a href="/about">About</a>  
      </div>  
      <Routes>
        {/* <Route path='경로' element={컴포넌트} /> */}
        <Route path='/home' element={<Home />} />
        <Route path='/content' element={<Content />} />
        <Route path='/about' element={<About />} />
      </Routes>  
     
    </div>
      
      {/* <div className='link'>
        <Link to={"/"}>Home</Link>  
        <Link to={"/content"}>Content</Link>  
        <Link to={"/about"}>About</Link>  
      </div> */}
      {/* 깜빡거림- 페이지 전체 리렌더링링 */}
       
    </div>
  );
}

export default App

