import { useState } from "react";
import "./css/List.css";
import Item from "./Item";

const List = ({todo, onUpdate}) =>{
const [search, setSearch] = useState("");

const onChangeSearch = (e) =>{
  setSearch(e.target.value);
} 

const getSearchResult = () =>{
  return search === "" ? todo :
   todo.filter((it) => it.content.toLowerCase().includes(search.toLowerCase()));
};

return(
    <div className="List">
      <h4>Todo List 🌳</h4>
      <input className="searchbar"
       value={search}
       onChange={onChangeSearch}      
      placeholder="검색어를 입력하세요" />
      <div className="todolist_wrapper">
       {
         getSearchResult().map((it) =>{
         return <Item {...it}  key={it.id} onUpdate={onUpdate} />
         })
       }
      </div>
    </div>
  );
}
export default List;