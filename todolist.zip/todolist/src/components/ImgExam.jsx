const ImgExam=()=>{
  return(
    <div>
      
    
    </div>
  );
}
export default ImgExam;