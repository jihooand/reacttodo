import { useParams } from "react-router-dom";
const Editor1=()=>{
  const params=useParams();
  console.log(params);
  const {id}=useParams();
  console.log(id);
  return(
    <div className="Editor1">
      <h1>Editor1</h1>
      <h1>{id}번 내용을 보여줍니다.</h1>
    </div>
  );
}
export default Editor1;