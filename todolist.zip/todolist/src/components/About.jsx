import "./css/About.css";
const About=()=>{
  
  return(
    <div className="About">
      <h1>About Page</h1>
    </div>
  );
}
export default About;