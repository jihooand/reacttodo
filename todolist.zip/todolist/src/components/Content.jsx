import "./css/Content.css";

import st1 from "../assets/images/statue1.jpg";
import st2 from "../assets/images/statue2.jpg";
import st3 from "../assets/images/statue3.jpg";
import st4 from "../assets/images/statue4.jpg";
const Content=()=>{

  return(
    <div className="Content">
      <h1>Content Page</h1>
      <img src={st1} width={100} height={200}/>
      <img src={st2} width={100} height={200} />
      <img src={st3} width={100} height={200} />
      <img src={st4} width={100} height={200} />
    </div>
  );
}
export default Content;